package com.example.emailmarketing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailMarketingApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailMarketingApplication.class, args);
	}

}
