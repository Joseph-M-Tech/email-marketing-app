package com.example.emailmarketing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailMarketingApplicationTests {

	@Test
	void contextLoads() {
	}

}
